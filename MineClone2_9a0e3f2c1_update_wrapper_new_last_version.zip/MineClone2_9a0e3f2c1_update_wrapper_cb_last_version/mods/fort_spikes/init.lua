-- init file for fort_spikes
local modpath = minetest.get_modpath("fort_spikes");
dofile(modpath.."/fort_spikes.lua")